from django.apps import AppConfig


class InfringementsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'infringements'
