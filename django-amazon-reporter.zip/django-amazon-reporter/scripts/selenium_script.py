def run_selenium_script(report_data:dict):
    a = 1
    if a == 1:
        return report_data
    else:
        return f'error'